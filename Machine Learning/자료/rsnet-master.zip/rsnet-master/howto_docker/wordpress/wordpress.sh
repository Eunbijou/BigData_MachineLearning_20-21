#!/bin/bash
make -f /opt/wordpress/Makefile $@