#!/bin/bash
make -f /data/notebooks/rsnet/system/docker/dev.make $@