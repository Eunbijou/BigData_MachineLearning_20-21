#!/bin/bash
make -f /data/notebooks/rsnet/howto_docker/dev.make $@