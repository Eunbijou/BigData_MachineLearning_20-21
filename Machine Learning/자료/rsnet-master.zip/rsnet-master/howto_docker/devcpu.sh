#!/bin/bash
make -f /data/notebooks/rsnet/how_to_make_system/docker/devcpu.make $@