#!/bin/bash
make -f ./portainer.make $@