#!/bin/bash
make -f /data/notebooks/rsnet/system/docker/dis.make $@