# -*- coding: utf-8 -*-
from pkg_resources import get_distribution, DistributionNotFound
from .jupyter import *
from .EduPlot import *
